<?php

use Illuminate\Support\Facades\Route;
use App\Http\Controllers\SubjectScreening;

Route::get('/', function () {
    return view('get_screening');
});

// Route::post('/save-screening', [SubjectScreening::class, 'savescreening'])->name('save-screening');
Route::post('/save-screening', [SubjectScreening::class, 'saveScreening'])->name('save-screening');
Route::get('/screening-result', [SubjectScreening::class, 'screeningResult'])->name('screening-result');

