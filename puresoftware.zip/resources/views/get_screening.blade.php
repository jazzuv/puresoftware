
<!doctype html>
<html lang="en" data-bs-theme="auto">
  <head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="">
    <meta name="author" content="Mark Otto, Jacob Thornton, and Bootstrap contributors">
    <meta name="generator" content="Hugo 0.122.0">
    <title>Subject Screening</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/@docsearch/css@3">
    <link href="/css/bootstrap.min.css" rel="stylesheet">
    <!-- Custom styles for this Subject Screening Form -->
    <link href="/custom.css" rel="stylesheet">
  </head>
 
  <body class="d-flex align-items-center py-4 bg-body-tertiary">  

  <main class="form-signin w-50 m-auto">
        <a href=" {{ route('screening-result') }}" class=" list-group-item-action active" aria-current="true">
            <button type="button" class="btn btn-success">Show Results </button>
        </a>
      <form action="{{ route('save-screening') }}" method="POST"  >
            @csrf

            <div class="form-floating  my-3">                      
              @if (\Session::has('message'))
                <div class="alert alert-danger">
                    <ul>
                        <li>{!! \Session::get('message') !!}</li>
                    </ul>
                </div>
              @endif
            </div>

            <!-- <img class="mb-4" src="../assets/brand/bootstrap-logo.svg" alt="" width="72" height="57"> -->
            <h1 class="h3 mb-3 fw-normal">Subject Screening Form</h1>

            <div class="form-floating  my-3">
              <input type="name" name="subject_name" class="form-control" id="firstName" placeholder="Enter Name" value="{{ old('subject_name') }}">
              <label for="firstName">Enter Name</label>
               @error('subject_name')
                    <div class="text-red-600">{{ $message }}</div>
                @enderror
            </div>
            <div class="form-floating  my-3">
              <input type="date" name="subject_dob" class="form-control" id="dateOfBirth" placeholder="Date Of Birth" min="1916-05-10" max="2024-05-10" value="{{ old('subject_dob') }}">
              <label for="dateOfBirth">Date Of Birth</label>
                @error('subject_dob')
                    <div class="text-red-600">{{ $message }}</div>
                @enderror
            </div>

            <div class="form-floating  my-3">
                <div class="dropdown">
                    <!-- <label for="dateOfBirth">Migraine Headaches Frequency: </label>  -->
                    <select onchange="selectHeadaches(this.value)" name="subject_headache" id="subject_headache" class="form-select" aria-label="Default select example">
                      <option value="">Select Migraine Frequency:</option>
                      <option value="monthly" {{ old("subject_headache") == "monthly" ? "selected" : "" }}>Monthly</option>
                      <option value="weekly" {{ old("subject_headache") == "weekly" ? "selected" : "" }}>Weekly</option>
                      <option value="daily" {{ old("subject_headache") == "daily" ? "selected" : "" }}>Daily</option>
                    </select>
                     @error('subject_headache')
                        <div class="text-red-600">{{ $message }}</div>
                     @enderror
                </div>
            </div>

            <div id="frequency" class="form-floating  my-3">
                <div class="dropdown">
                    <!-- <label for="dateOfBirth">Daily Experience Frequency: </label>  -->
                    <select name="subject_headache_frequency" class="form-select" aria-label="Default select example">
                      <option value="">Select Daily Experience Frequency</option>
                      <option value="1-2" {{ old("subject_headache_frequency") == "1-2" ? "selected" : "" }}>1-2</option>
                      <option value="3-4" {{ old("subject_headache_frequency") == "3-4" ? "selected" : "" }}>3-4</option>
                      <option value="5+" {{ old("subject_headache_frequency") == "5+" ? "selected" : "" }}>5+</option>
                    </select>
                     @error('subject_headache_frequency')
                        <div class="text-red-600">{{ $message }}</div>
                     @enderror
                </div>
            </div>
        <button class="btn btn-primary w-50 py-2" type="submit">Submit Data</button>
    </form>
  </main>

<!-- bootstrap js file --->
<script src="/js/bootstrap.bundle.min.js"></script>
<script>
  
  // Select Headaches is Monthly / weekly / Daily
  function selectHeadaches(val){
      var x = document.getElementById("frequency");
      if(val!==''){
           if(val==='daily'){                            
              x.style.display = "block";
           } else {              
              x.style.display = "none";
           } 
      }
  }

  // if Daily Selected & other laravel Validation fail then option enable on reload
  window.onload = function() {
     // Parent Headache Column 
     var xVal = document.getElementById("subject_headache").value;
     if(xVal==='daily'){
      // Headache frequency 1-2 , 3-4, 5+
      document.getElementById('frequency').style.display = 'block';
     }
  }

</script>

</body>
</html>
