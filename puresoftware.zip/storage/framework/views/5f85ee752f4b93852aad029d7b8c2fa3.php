
<!doctype html>
<html lang="en" data-bs-theme="auto">
  <head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="">
    <meta name="author" content="Mark Otto, Jacob Thornton, and Bootstrap contributors">
    <meta name="generator" content="Hugo 0.122.0">
    <title>Subject Screening Result Page</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/@docsearch/css@3">
    <link href="/css/bootstrap.min.css" rel="stylesheet">
    <!-- Custom styles for this Subject Screening Form -->
    <link href="/custom.css" rel="stylesheet">
  </head>
 
  <body class="d-flex align-items-center py-4 bg-body-tertiary">  




  <main class="form-signin w-100 m-auto">
        
            <div class="form-floating  my-3">                      
              <?php if(\Session::has('message')): ?>
                <div class="alert alert-success">
                    <ul>
                        <li><?php echo \Session::get('message'); ?></li>
                    </ul>
                </div>
              <?php endif; ?>
            </div> 

            
          <a href="/" class=" list-group-item-action active" aria-current="true">
            <button type="button" class="btn btn-primary">Subject Sceening Form</button>
          </a>

          <a href=" <?php echo e(route('screening-result')); ?>" class=" list-group-item-action active" aria-current="true">
            <button type="button" class="btn btn-success">Result Page</button>
          </a>

  
 
        <table class="table">
          <thead>
            <tr>
              <th scope="col">#</th>
              <th scope="col">Subject Name</th>
              <th scope="col">Subject DOB</th>
              <th scope="col">Migraine Headaches </th>
              <th scope="col">Headaches Frequency</th>
              <th scope="col">Assigned Doctor</th>
            </tr>
          </thead>
          <tbody>
            
                <!-- <?php if(count($results)>0): ?> -->
                <?php $__currentLoopData = $results; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $result): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                  
                  <tr>
                    <th scope="row"><?php echo e($key+1); ?></th>
                    <td><?php echo e($result->subject_name); ?></td>
                    <td><?php echo e($result->subject_dob); ?></td>
                    <td><?php echo e($result->subject_headache); ?></td>
                    <td><?php echo e($result->subject_headache_frequency ? $result->subject_headache_frequency : "N/A"); ?></td>
                    <td><?php echo e($result->assign->assigned_doctor); ?></td>
                  </tr>

                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <!-- <?php else: ?> -->
                <!-- <p> empty </p> -->
                <!-- <?php endif; ?> -->

          </tbody>
        </table>





    </main>

<!-- bootstrap js file --->
<script src="/js/bootstrap.bundle.min.js"></script>

</body>
</html>
<?php /**PATH /var/www/html/subject-screening/resources/views/result.blade.php ENDPATH**/ ?>