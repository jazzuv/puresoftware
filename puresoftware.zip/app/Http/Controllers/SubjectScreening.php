<?php

namespace App\Http\Controllers;


use Illuminate\Http\Request;
// use Illuminate\Support\Facades\Redirect;
use Carbon\Carbon;
use App\Models\Subject;
use App\Models\Assign;
use DB;


class SubjectScreening extends Controller
{
    /**
     * Display a listing of the resource.
     */
    public function index()
    {
        session->flush();   
    }

    /**
     * Save a newly screening data in database.
     */
    public function saveScreening(Request $request)
    {
         // Validate the incoming request data
        $validatedData = $request->validate([
            'subject_name' => 'required|max:30',
            'subject_dob' => 'required|date|before:today|date_format:Y-m-d',
            'subject_headache' => 'required',
            'subject_headache_frequency' => 'required_if:subject_headache,daily'
        ]);
        
        // Convert date of birth into proper Age figure 
        $age = Carbon::parse($request->input("subject_dob"))->age; 

        if( $age<18 ){

            return redirect()->back()->with('message', 'Participants must be over 18 years of age'); 

        } else if( $age>18 &&  (in_array(strtolower($request->input("subject_headache")), array('monthly','weekly')))) {     
        
           
            $result = Subject::create(request(['subject_name', 'subject_dob', 'subject_headache']));
            if($result->id){
                Assign::create(['subject_id'=>$result->id, 'assigned_doctor'=>'Cohort A']);
            }

            return redirect()->route('screening-result')->with('message','Participants '.$request->input("subject_name").' is assigned to Cohort A');

        } else if( $age>18 &&  (strtolower($request->input("subject_headache"))==='daily')) {
            
            
            $result = Subject::create(request(['subject_name', 'subject_dob', 'subject_headache','subject_headache_frequency']));
            if($result->id){
                Assign::create(['subject_id'=>$result->id, 'assigned_doctor'=>'Cohort B']);
            }
            
            return redirect()->route('screening-result')->with('message','Participants '.$request->input("subject_name").' is assigned to Cohort B');

        } else {

            return redirect()->back()->with('message','Something went wrong!');

        }    

    }

    /**
     * show
     * Display the Subject screening Data.
     */
    public function screeningResult()
    {

        $results = Subject::with('assign')->get();      
        return view('result',["results"=>$results]);
    }

    /**
     * Show the form for editing the specified resource.
     */
    public function edit(string $id)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     */
    public function update(Request $request, string $id)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     */
    public function destroy(string $id)
    {
        //
    }
}
