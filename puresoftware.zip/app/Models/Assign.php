<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Assign extends Model
{
    use HasFactory;
    // protected $table    = 'assigns';
    protected $fillable     = ['subject_id', 'assigned_doctor'];
    protected $primaryKey   = 'subject_id';

}
