<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Subject extends Model
{
    use HasFactory;
    // protected $table    = 'Subject';
    protected $fillable = ['subject_name', 'subject_dob','subject_headache','subject_headache_frequency'];
    
    public function assign()
    {
        return $this->belongsTo('App\Models\Assign','subject_id');
    }



    //  public function assign()
    // {
    //     return $this->belongsTo(Assign::class);
    // }
}
